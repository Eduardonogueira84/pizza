// Importe o Express e crie um roteador
const express = require('express');
const router = express.Router();

// Importe o controlador da pizza (certifique-se de criar o arquivo pizzaController.js)
const pizzaController = require('../controllers/pizzaController');

// Rota para obter todas as pizzas
router.get('/pizzas', pizzaController.getAllPizzas);

// Rota para obter uma pizza por ID
router.get('/pizzas/:id', pizzaController.getPizzaById);

// Rota para criar uma nova pizza
router.post('/pizzas', pizzaController.createPizza);

// Rota para atualizar uma pizza existente
router.put('/pizzas/:id', pizzaController.updatePizza);

// Rota para excluir uma pizza
router.delete('/pizzas/:id', pizzaController.deletePizza);

// Exporte o roteador para ser usado em app.js
module.exports = router;
