// Importe o modelo de pizza, se aplicável
const Pizza = require('../models/pizzaModel');

// Função de callback para obter todas as pizzas
exports.getAllPizzas = async (req, res) => {
  try {
    const pizzas = await Pizza.find();
    res.status(200).json(pizzas);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar todas as pizzas' });
  }
};

// Função de callback para obter uma pizza por ID
exports.getPizzaById = async (req, res) => {
  const pizzaId = req.params.id;

  try {
    const pizza = await Pizza.findById(pizzaId);
    if (!pizza) {
      return res.status(404).json({ error: 'Pizza não encontrada' });
    }
    res.status(200).json(pizza);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar a pizza por ID' });
  }
};

// Função de callback para criar uma nova pizza
exports.createPizza = async (req, res) => {
  const { name, description, price } = req.body;

  try {
    const newPizza = new Pizza({ name, description, price });
    const pizza = await newPizza.save();
    res.status(201).json(pizza);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao criar a nova pizza' });
  }
};

// Função de callback para atualizar uma pizza existente
exports.updatePizza = async (req, res) => {
  const pizzaId = req.params.id;
  const { name, description, price } = req.body;

  try {
    const pizza = await Pizza.findByIdAndUpdate(
      pizzaId,
      { name, description, price },
      { new: true }
    );
    if (!pizza) {
      return res.status(404).json({ error: 'Pizza não encontrada' });
    }
    res.status(200).json(pizza);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao atualizar a pizza' });
  }
};

// Função de callback para excluir uma pizza
exports.deletePizza = async (req, res) => {
  const pizzaId = req.params.id;

  try {
    const pizza = await Pizza.findByIdAndRemove(pizzaId);
    if (!pizza) {
      return res.status(404).json({ error: 'Pizza não encontrada' });
    }
    res.status(204).json();
  } catch (error) {
    res.status(500).json({ error: 'Erro ao excluir a pizza' });
  }
};
