const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const pizzaRoutes = require('./routes/pizzaRoutes');
const swaggerUi = require('swagger-ui-express');
const YAML = require('yamljs'); // Importe a biblioteca YAML

app.use(bodyParser.json());

app.use('/api', pizzaRoutes);

// Carregue o arquivo de especificação OpenAPI (Swagger)
const swaggerDocument = YAML.load('./swagger.yaml'); // Especificação definida no arquivo swagger.yaml

// Configure o Swagger UI
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});
