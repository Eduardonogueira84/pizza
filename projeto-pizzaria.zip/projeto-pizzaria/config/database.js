// database.js
const mongoose = require('mongoose');

const dbUrl = 'mongodb://localhost:27017/teste'; // Substitua com a URL do seu banco

mongoose.connect(dbUrl, { useNewUrlParser: true, useUnifiedTopology: true });

const db = mongoose.connection;

db.on('error', console.error.bind(console, 'Erro na conexão com o banco de dados:'));
db.once('open', () => {
  console.log('Conexão com o banco de dados estabelecida.');
});

module.exports = db;
