// config/jwt.js
const jwt = require('jsonwebtoken');
const secretKey = 'sua_chave_secreta';

module.exports = {
  generateToken: (user) => {
    return jwt.sign({ id: user._id, email: user.email }, secretKey, { expiresIn: '1h' });
  },
  verifyToken: (token) => {
    try {
      return jwt.verify(token, secretKey);
    } catch (error) {
      return null;
    }
  },
};
